from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired, data_required

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[data_required()])
    password = PasswordField('password', validators = [DataRequired()])
    remember_me = BooleanField('remeber me')
    entra = SubmitField('Invio')

